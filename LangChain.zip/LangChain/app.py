from fastapi import FastAPI
from langchain.prompts import ChatPromptTemplate
from langchain.chat_models import ChatOpenAI
from langserve import add_routes
import uvicorn, os
from langchain_community.llms import ollama
import streamlit as st
import LangChain

st.title('Restaurant name generator')

cuisine = st.sidebar.selectbox("Pick a cuisine", ("Indian", "Malaysian", "American", "Spanish", "Italian", "Mexican", "Thai", "Australian", "English", "African", "german", "kiwi", "Tamil", "French", "Dutch", "Portuguese"))
if cuisine:
    response = LangChain.generate(cuisine)
    st.header(response['restaurant_name'].strip())
    menu_items = response['menu_items'].split(",")
    st.write("menu items: ")
    for item in menu_items:
        st.write("-", item)