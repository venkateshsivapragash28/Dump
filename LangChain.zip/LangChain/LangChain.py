from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain, SequentialChain
import os

# Set the API key
os.environ["GOOGLE_API_KEY"] = "AIzaSyDGOdBnd43a8YKza0V3jzKBnCdedoUjVH0"

# Load the Gemini model
llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash")

def generate(cuisine):
    # Prompt to suggest restaurant name
    prompt_template_name = PromptTemplate(
        input_variables=["cuisine"],
        template="I want to open a restaurant for {cuisine} food, suggest strictly one name for that."
    )
    name_chain = LLMChain(llm=llm, prompt=prompt_template_name, output_key='restaurant_name')

    # Prompt to suggest menu
    prompt_template_items = PromptTemplate(
        input_variables=['restaurant_name'],
        template="Suggest me the menu for my restaurant named {restaurant_name}."
    )
    items_chain = LLMChain(llm=llm, prompt=prompt_template_items, output_key='menu_items')

    # Combine the two chains
    chain = SequentialChain(
        chains=[name_chain, items_chain],
        input_variables=['cuisine'],
        output_variables=['restaurant_name', 'menu_items']
    )

    # Use invoke() instead of run() to support multiple outputs
    response = chain.invoke({"cuisine": cuisine})
    return response

# Main block — should be outside of the function
if __name__ == '__main__':
    result = generate('Indian')
    print("Restaurant Name:", result['restaurant_name'])
    print("Menu Items:", result['menu_items'])
